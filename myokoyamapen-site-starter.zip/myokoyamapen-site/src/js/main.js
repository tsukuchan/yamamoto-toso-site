document.addEventListener("DOMContentLoaded", () => {
  console.log("Tailwind starter loaded.");
});
